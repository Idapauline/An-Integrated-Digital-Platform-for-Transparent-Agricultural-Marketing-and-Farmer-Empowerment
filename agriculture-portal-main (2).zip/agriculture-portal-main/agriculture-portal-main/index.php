<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer's Assistance Portal - Home</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
        }

        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #2e7d32 0%, #388e3c 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            font-size: 40px;
        }

        .site-title {
            font-size: 28px;
            font-weight: bold;
        }

        .nav-menu {
            display: flex;
            gap: 30px;
            list-style: none;
        }

        .nav-menu a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.2);
            transform: translateY(-2px);
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, #66bb6a 0%, #43a047 100%);
            color: white;
            padding: 80px 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120"><path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" fill="%23ffffff"/><path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" fill="%23ffffff"/><path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" fill="%23ffffff"/></svg>') no-repeat bottom;
            background-size: cover;
            opacity: 0.1;
        }

        .hero-content {
            max-width: 1000px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
            opacity: 0.95;
        }

        .hero-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 15px 40px;
            font-size: 16px;
            font-weight: 600;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: #ffa726;
            color: white;
            box-shadow: 0 4px 15px rgba(255,167,38,0.4);
        }

        .btn-primary:hover {
            background: #ff9800;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255,167,38,0.6);
        }

        .btn-secondary {
            background: white;
            color: #2e7d32;
            box-shadow: 0 4px 15px rgba(255,255,255,0.3);
        }

        .btn-secondary:hover {
            background: #f5f5f5;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255,255,255,0.5);
        }

        /* Role Cards Section */
        .role-section {
            max-width: 1200px;
            margin: -50px auto 60px;
            padding: 0 20px;
            position: relative;
            z-index: 2;
        }

        .section-title {
            text-align: center;
            font-size: 36px;
            color: #2e7d32;
            margin-bottom: 50px;
        }

        .role-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .role-card {
            background: white;
            border-radius: 15px;
            padding: 40px 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .role-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }

        .role-icon {
            font-size: 60px;
            margin-bottom: 20px;
        }

        .role-card h3 {
            font-size: 24px;
            color: #2e7d32;
            margin-bottom: 15px;
        }

        .role-card p {
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .role-card .btn-small {
            padding: 10px 25px;
            font-size: 14px;
            border-radius: 25px;
        }

        /* Features Section */
        .features-section {
            max-width: 1200px;
            margin: 80px auto;
            padding: 0 20px;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .feature-item {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }

        .feature-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }

        .feature-icon {
            font-size: 40px;
            margin-bottom: 15px;
        }

        .feature-item h4 {
            font-size: 20px;
            color: #2e7d32;
            margin-bottom: 10px;
        }

        .feature-item p {
            color: #666;
            line-height: 1.6;
            font-size: 14px;
        }

        /* Stats Section */
        .stats-section {
            background: linear-gradient(135deg, #2e7d32 0%, #388e3c 100%);
            color: white;
            padding: 60px 20px;
            text-align: center;
        }

        .stats-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
        }

        .stat-item {
            padding: 20px;
        }

        .stat-number {
            font-size: 48px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .stat-label {
            font-size: 18px;
            opacity: 0.9;
        }

        /* Footer */
        .footer {
            background: #1b5e20;
            color: white;
            padding: 40px 20px 20px;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 30px;
        }

        .footer-section h4 {
            font-size: 20px;
            margin-bottom: 15px;
        }

        .footer-section p,
        .footer-section a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            line-height: 2;
            font-size: 14px;
        }

        .footer-section a:hover {
            color: white;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.2);
            color: rgba(255,255,255,0.7);
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 20px;
            }

            .nav-menu {
                flex-wrap: wrap;
                justify-content: center;
            }

            .hero h1 {
                font-size: 32px;
            }

            .hero p {
                font-size: 16px;
            }

            .section-title {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="logo">🌾</div>
                <div class="site-title">Farmer's Assistance Portal</div>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a >About</a></li>
                    <li><a >Services</a></li>
                    <li><a >Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Empowering Farmers with Smart Agriculture</h1>
            <p>AI-Powered Crop Recommendations | Yield Predictions | Smart Trading Platform</p>
            <div class="hero-buttons">
                <a href="register.php" class="btn btn-primary">Get Started</a>
                <a  class="btn btn-secondary">Learn More</a>
            </div>
        </div>
    </section>

    <!-- Role Cards Section -->
    <section class="role-section">
        <h2 class="section-title">Choose Your Role</h2>
        <div class="role-cards">
            <div class="role-card" onclick="location.href='farmer/fregister.php'">
                <div class="role-icon">👨‍🌾</div>
                <h3>Farmer</h3>
                <p>Get AI-powered crop recommendations, yield predictions, rainfall forecasts, and trade your produce directly with customers.</p>
                <a href="farmer/fregister.php" class="btn btn-primary btn-small">Farmer Portal</a>
            </div>

            <div class="role-card" onclick="location.href='customer/cregister.php'">
                <div class="role-icon">🛒</div>
                <h3>Customer</h3>
                <p>Browse fresh crops directly from farmers, check stock availability, and purchase quality agricultural products online.</p>
                <a href="customer/cregister.php" class="btn btn-primary btn-small">Customer Portal</a>
            </div>

            <div class="role-card" onclick="location.href='admin-login.php'">
                <div class="role-icon">⚙️</div>
                <h3>Admin</h3>
                <p>Manage farmers and customers, monitor platform activities, respond to queries, and ensure smooth operations.</p>
                <a href="admin/alogin.php" class="btn btn-primary btn-small">Admin Portal</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
        <h2 class="section-title">Platform Features</h2>
        <div class="features-grid">
            <div class="feature-item">
                <div class="feature-icon">🌱</div>
                <h4>Crop Recommendation</h4>
                <p>AI-based suggestions for best crops to grow based on soil and climate conditions.</p>
            </div>

            <div class="feature-item">
                <div class="feature-icon">💧</div>
                <h4>Fertilizer Guidance</h4>
                <p>Get optimal fertilizer recommendations for maximum crop yield.</p>
            </div>

            <div class="feature-item">
                <div class="feature-icon">📊</div>
                <h4>Yield Prediction</h4>
                <p>Predict your crop yield before harvest using advanced ML algorithms.</p>
            </div>

            <div class="feature-item">
                <div class="feature-icon">🌧️</div>
                <h4>Rainfall Forecast</h4>
                <p>Accurate rainfall predictions to help plan farming activities.</p>
            </div>

            <div class="feature-item">
                <div class="feature-icon">💰</div>
                <h4>Direct Trading</h4>
                <p>Sell your crops directly to customers without intermediaries.</p>
            </div>

            <div class="feature-item">
                <div class="feature-icon">🤖</div>
                <h4>AI Chatbot</h4>
                <p>24/7 assistance for all your farming queries and doubts.</p>
            </div>

            <div class="feature-item">
                <div class="feature-icon">📰</div>
                <h4>News Feed</h4>
                <p>Stay updated with latest agricultural news and market trends.</p>
            </div>

            <div class="feature-item">
                <div class="feature-icon">🌤️</div>
                <h4>Weather Forecast</h4>
                <p>Real-time weather updates for better farm management.</p>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="stats-container">
            <div class="stat-item">
                <div class="stat-number">5000+</div>
                <div class="stat-label">Registered Farmers</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">10000+</div>
                <div class="stat-label">Happy Customers</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">50+</div>
                <div class="stat-label">Crop Varieties</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">98%</div>
                <div class="stat-label">Accuracy Rate</div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>About Us</h4>
                <p>Farmer's Assistance Portal is dedicated to empowering farmers with technology and connecting them directly with customers.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <p><a >About</a></p>
                <p><a >Services</a></p>
                <p><a >Contact</a></p>
                <p><a >FAQ</a></p>
            </div>
            <div class="footer-section">
                <h4>Services</h4>
                <p><a href="#">Crop Recommendation</a></p>
                <p><a href="#">Yield Prediction</a></p>
                <p><a href="#">Trading Platform</a></p>
                <p><a href="#">Weather Forecast</a></p>
            </div>
            <div class="footer-section">
                <h4>Contact Info</h4>
                <p>📧 Email: support@farmerassist.com</p>
                <p>📞 Phone: +91 1234567890</p>
                <p>📍 Location: SMVITM, Karnataka</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Farmer's Assistance Portal. All rights reserved. | Dept. of CSE, SMVITM</p>
        </div>
    </footer>
</body>
</html>